/* feedreader.js
 *
 * This is the spec file that Jasmine will read and contains
 * all of the tests that will be run against your application.
 */

/* We're placing all of our tests within the $() function,
 * since some of these tests may require DOM elements. We want
 * to ensure they don't run until the DOM is ready.
 */

$(function() {

    /* This is our first test suite - a test suite just contains
    * a related set of tests. This suite is all about the RSS
    * feeds definitions, the allFeeds variable in our application.
    */

  // Testing suite of RSS Feed
  describe('RSS Feeds', function() {

        /* This is our first test - it tests to make sure that the
        * allFeeds variable has been defined and that it is not
        * empty. Experiment with this before you get started on
        * the rest of this project. What happens when you change
        * allFeeds in app.js to be an empty array and refresh the
        * page?
        */

    //  Function to make sure that all feeds are defined and are not empty
    it('all Feeds are defined and not empty', function() {
      expect(allFeeds).toBeDefined();
      expect(allFeeds.length).not.toBe(0);
    });

   //  Function to make sure that URL's of each feed is defined and are not empty
   it('Each feed of allFeeds object have a URL defined and not empty', function() {
     allFeeds.forEach(function(feed) {
       expect(feed.url).toBeDefined();
       expect(feed.url.length).not.toBe(0);
     });
   });

    //  Function to make sure that name's of each feed is defined and are not empty
    it('Each feed of allFeeds object have a name defined and not empty', function() {
      allFeeds.forEach(function(feed) {
        expect(feed.name).toBeDefined();
        expect(feed.name.length).not.toBe(0);
      });
    });
  });


  // Testing suite for Menu
  describe('The menu', function() {

    // Pre-defined elements for this suite
    var body, menuIcon, menuHide;
    body = $('body');
    menuHide = body.hasClass('menu-hidden');

    //  function to have the menu hidden initially
    it('Menu element is hidden by default', function() {
      expect(menuHide).toBe(true);
    });

    // Function to have the menu shown/hidden on clicking
    it('Menu element changes visibility when the menu icon is clicked', function() {
      menuIcon = $('.menu-icon-link');

      menuIcon.click();
      expect(body.hasClass('menu-hidden')).toEqual(false);

      menuIcon.click();
      expect(menuHide).toEqual(true);
    });
  });


  // Testing suite for Initial Entries
  describe('Initial Entries', function() {

    //  beforeEach to wait for async all to finish
    beforeEach(function(done) {
      loadFeed(0, done);
    });

    //  Function to check feed container has at least one entry
    it('Feed container has at least one entry after call', function() {
      var totalEntries = $('.feed .entry').length;
      expect(totalEntries).toBeGreaterThan(0);
    });
  });


  //  Testing suite for New Feed Selection
  describe('New Feed Selection', function() {
    var presentFeed, newFeed;

    //  beforeEach to wait for async all to finish
    beforeEach(function(done) {
      loadFeed(0, function() {
        presentFeed = $('.feed').html();
        
        loadFeed(1, function() {
          done();
        });
      });
    });

    //  function for the content to change when new feed is loaded
    it('When new feed is loaded the displayed content changes', function(done) {
      newFeed = $('.feed').html();
      expect(presentFeed).not.toBe(newFeed);
      done();
    });
  });
}());
